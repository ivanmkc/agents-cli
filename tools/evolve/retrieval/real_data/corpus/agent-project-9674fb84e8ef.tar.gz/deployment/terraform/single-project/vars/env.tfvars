# Project name used for resource naming
project_name = "agent-project"

# Your Google Cloud project id
project_id = "your-gcp-project-id"

# The Google Cloud region you will use to deploy the infrastructure
region = "us-east1"
